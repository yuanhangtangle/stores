#include <assert.h>
#include <ctype.h>
#include <dirent.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// status related
#define PROC "/proc/"
#define STAT "/proc/%d/status"
#define maxN 5000
#define ROOT "systemd"
// file scanning related
#define fscanstr(v)                                                            \
  { fscanf(fp, "%s", (v)); }
#define fscanInt(v)                                                            \
  { fscanf(fp, "%d", (v)); }
#define scanfUtil(s)                                                           \
  {                                                                            \
    while (strcmp(discard, s) != 0) {                                          \
      fscanf(fp, "%s", discard);                                               \
    }                                                                          \
  }
// iteration
#define loop(v) for (int i = 0; i < (v); ++i)

struct _proc {
  int pid, ppid, nChilds;
  struct _proc *childs[1000];
  struct _proc *pa;
  char comm[80];
};

typedef struct _proc proc;
typedef int pid_index;
char discard[80];
proc *procs[maxN], *root;
int N = 0;
DIR *dir;
FILE *fp;
char *end;
pid_index idx;
struct dirent *filep;
bool flagV = false;
bool flagP = false;
bool flagN = false;

pid_index binSearch(int pid) {
  int lo, mi, hi;
  lo = 0;
  hi = N - 1;
  while (hi >= lo) {
    mi = (hi + lo) >> 1;
    if (procs[mi]->pid == pid)
      return mi;
    else if (procs[mi]->pid > pid)
      hi = mi - 1;
    else if (procs[mi]->pid < pid)
      lo = mi + 1;
  }
  return -1;
}

void printVersion() {
  fprintf(stderr, "first version writen at 2023/05/23\n");
  return;
}

void swapProc(int p, int q) {
  proc *t = procs[p];
  procs[p] = procs[q];
  procs[q] = t;
}

int partition(int lo, int hi) {
  int r = rand() % (hi - lo) + lo;
  swapProc(lo, r);
  proc *pivot = procs[lo];
  while (lo < hi) {
    do
      hi--;
    while ((lo < hi) & (pivot->pid < procs[hi]->pid));
    procs[lo] = procs[hi];
    do
      lo++;
    while ((lo < hi) & (pivot->pid > procs[hi]->pid));
    procs[lo] = procs[lo];
  }
  procs[hi] = pivot;
  return hi;
}

void quickSort(int lo, int hi) {
  if (hi - lo > 1) {
    int mi = partition(lo, hi);
    quickSort(lo, mi);
    quickSort(mi + 1, hi);
  }
}

pid_index findPid(int pid) {
  loop(N) {
    if (pid == (procs[i]->pid))
      return i;
  }
  return -1;
}

proc *newProc() {
  proc *p = (proc *)malloc(sizeof(proc));
  p->nChilds = 0;
  p->pa = NULL;
  return p;
}

proc *findRoot(proc *p) {
  proc *t = p;
  printf("%s %d\n", t->comm, t->pid);
  while ((t->pa) != NULL) {
    t = t->pa;
    printf("%s %d\n", t->comm, t->pid);
  }
  return t;
}

bool isInt(const char *s) {
  for (const char *c = s; *c != '\0'; ++c) {
    if (!isdigit(*c))
      return false;
  }
  return true;
}

void printProc(proc *p) {
  printf("pid: %d command: %s ppid: %d paNULL: %d\n", p->pid, p->comm, p->ppid,
         (p->pa == NULL));
  return;
}

proc *readStat(char *stat) {
  /*FILE *fp;*/
  proc *p;
  p = newProc();
  fp = fopen(stat, "r");
  if (!fp) {
    printf("failed to read file %s\n", stat);
    exit(1);
  } else {
    scanfUtil("Name:");
    fscanstr(p->comm);
    scanfUtil("Pid:");
    fscanInt(&(p->pid));
    scanfUtil("PPid:");
    fscanInt(&(p->ppid));
  }
  fclose(fp);
  return p;
}

void readProcs(char *base) {
  char stat[80];
  proc *p;
  dir = opendir(PROC);
  if (!dir) {
    printf("failed to open dir %s", PROC);
    exit(1);
  } else {
    while ((filep = readdir(dir)) != NULL) {
      if (isInt(filep->d_name)) {
        int _pid = strtol(filep->d_name, &end, 10);
        sprintf(stat, STAT, _pid);
        p = readStat(stat);
        procs[N++] = p;
        if ((strcmp(p->comm, ROOT) == 0) & (p->ppid == 0))
          root = p;
      }
    }
  }
  closedir(dir);
  printf("number of read processes = %d\n", N);
}

void buildTree() {
  for (int i = 0; i < N; ++i) {
    proc *p = procs[i];
    pid_index idx = binSearch(p->ppid);
    /*printf("pid: %d ppid: %d parent idx: %d\n", p->pid, p->ppid, idx);*/
    if (idx > -1) {
      proc *pp = procs[idx];
      pp->childs[(pp->nChilds)++] = p;
      p->pa = pp;
    }
  }
}

void showTreeByTab(proc *p, int level) {
  // indents
  for (int i = 0; i < level; ++i) {
    printf("  ");
  }
  // print command and pid
  if (flagP) {
    printf("%s(%d)\n", p->comm, p->pid);
  } else {
    printf("%s\n", p->comm);
  }
  // print its childs
  for (int i = 0; i < (p->nChilds); ++i) {
    proc *c = p->childs[i];
    showTreeByTab(c, level + 1);
  }
}

void showTree1(proc *p, int level) {
  loop(level - 1) { printf("|\t"); }
  if (level > 0) {
    printf("|-------");
  }
  printf("%s\n", p->comm);
  for (int i = 0; i < (p->nChilds); ++i) {
    proc *c = p->childs[i];
    showTree1(c, level + 1);
  }
}

int main(int argc, char *argv[]) {
  char *a;
  loop(argc) {
    if (i > 0) {
      a = argv[i];
      switch (a[1]) {
      case 'V':
        flagV = true;
        break;
      case 'p':
        flagP = true;
        break;
      case 'n':
        flagN = true;
        break;
      }
    }
  };
  if (flagV)
    printVersion();
  if (flagN | flagP) {
    if (flagN) {
      quickSort(0, N);
    }
    readProcs(PROC);
    buildTree();
    showTreeByTab(root, 0);
    return 0;
  }
}
