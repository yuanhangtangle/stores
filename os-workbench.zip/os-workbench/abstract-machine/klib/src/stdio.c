#include <am.h>
#include <cstddef>
#include <klib-macros.h>
#include <klib.h>
#include <stdarg.h>

#if !defined(__ISA_NATIVE__) || defined(__NATIVE_USE_KLIB__)

int printf(const char *fmt, ...) { panic("Not implemented"); }

int vsprintf(char *out, const char *fmt, va_list ap) {
  panic("Not implemented");
}

int sprintf(char *out, const char *fmt, ...) { panic("Not implemented"); }

int snprintf(char *out, size_t n, const char *fmt, ...) {
  panic("Not implemented");
}

int vsnprintf(char *out, size_t n, const char *fmt, va_list ap) {
  /**
   * at most n characters are writen to out
   * fmt are similar to that of printf
   * ap is a pointer to a list of variable arguments
   * */
  int m = 0; // characters writen by now
  char *c = fmt;
  while (*c) {
    if (*c == '%') {
      // begin specifier
      // copy formatted str
    } else {
      *out = *c;
      ++m, ++out;
    }
  }
  /*panic("Not implemented");*/
}

#endif
