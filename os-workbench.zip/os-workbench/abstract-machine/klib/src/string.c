#include <cstddef>
#include <klib-macros.h>
#include <klib.h>
#include <stddef.h>
#include <stdint.h>
#if !defined(__ISA_NATIVE__) || defined(__NATIVE_USE_KLIB__)

size_t strlen(const char *s) {
  size_t i;
  for (; s[i]; ++i) {
  };
  return i;
  /*panic("Not implemented");*/
}

char *strcpy(char *dst, const char *src) {
  char *d = dst;
  const char *s = src;
  for (; *s; s++, d++) {
    *d = *s;
  }
  return dst;
}

char *strncpy(char *dst, const char *src, size_t n) {
  /*
   *copy src to dst, but atmost n characters are copied
   * if '\0' is not included in src[0:n],
   * dst won't end with '\0'.
   */
  size_t i;
  for (i = 0; i < n && src[i] != '\0'; i++)
    dst[i] = src[i];
  for (; i < n; i++)
    dst[i] = '\0';
  return dst;
}

char *strcat(char *dst, const char *src) {
  char *d = dst;
  while (*d != '\0')
    ++d;
  for (const char *s = src; *s != '\0'; ++s) {
    *(d++) = *s;
  }
  *(++d) = '\0';
}

#endif
