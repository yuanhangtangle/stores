#include <assert.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>

char toChar(int);
char *itos(int, char *);
char *mystoi(char *s, int *d);
void putstr(char *s);

char *itos(int d, char *s) {
  /* convert a integer to string,
   * `s` will begins with '-' if d < 0
   * It is assumed that the length of `s` is sufficient
   */
  int n = 0;
  if (d == 0) {
    s[n++] = '0';
    s[n] = '\0';
    return s;
  }
  if (d < 0) {
    s[n++] = '-';
    d = -d;
  };
  while (d != 0) {
    s[n++] = toChar(d % 10);
    d /= 10;
  }
  s[n] = '\0';
  // reverse the sequence
  int l = 0;
  int r = n - 1;
  char c;
  if (s[0] == '-')
    ++l;
  while (l < r) {
    c = s[l];
    s[l] = s[r];
    s[r] = c;
    ++l, --r;
  }
  return s;
}

char *mystoi(char *src, int *d) {
  /*
   *try to convert `src` to integer and store it in `d`
   *skip all the blank in the beginning of src,
   *and convert the rest of characters as many as possible.
   *if succeeds, return a pointer pointing to the beginning of the
   *rest characters;
   *if fails, return a pointer to the beginning of `src`
   */
  int sign = 1;
  int r = 0;
  char *e = src;
  while ((*e == ' ') | (*e == '\t'))
    ++e;
  if (*e == '-') {
    sign = -1;
    ++e;
  }
  if ((*e < '0') | (*e > '9')) {
    e = src;
  } else {
    while ((*e >= '0') & (*e <= '9')) {
      r = r * 10 + (*e - '0');
      ++e;
    }
    *d = r * sign;
  }
  return e;
}

char toChar(int d) {
  assert((0 <= d) & (d < 10));
  return '0' + d;
}

void putstr(char *str) {
  for (char *c = str; *c; ++c) {
    putchar(*c);
  }
}

int vsnprintf(char *out, size_t n, const char *fmt, va_list ap) {
  int m = 0; // characters writen by now
  const char *c = fmt;
  while (*c) {
    if (*c == '%') {
      // begin specifier
      // copy formatted str
    } else {
      *out = *c;
      ++m, ++out, ++c;
    }
  }
}

int main() {
  /*char *s = (char *)malloc(80 * sizeof(char));*/
  char s[80] = "\0";
  char *e;
  int d = -99999;
  e = mystoi(s, &d);
  return 0;
}
