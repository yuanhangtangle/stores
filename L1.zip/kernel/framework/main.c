#include <kernel.h>
#include <klib.h>

int main() {
  os->init();
	// start multi-processing, located at am.h, which is included by kernel.h
	// os->run is the entry
	mpe_init(os->run);
  return 1;
}
