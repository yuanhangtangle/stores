typedef int spinlock_t;
#define SPIN_INIT() 0

static inline int atomic_xchg(volatile int *addr, int newval);
void spin_lock(spinlock_t *lk);
void spin_unlock(spinlock_t *lk);
