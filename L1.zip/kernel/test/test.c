
#include "common.h"
#include "thread.h"
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEBUG(...)                                                             \
  {                                                                            \
    spin_lock(&biglock);                                                       \
    debug(__FILE__, __LINE__, __VA_ARGS__);                                    \
    spin_unlock(&biglock);                                                     \
  }

#define ALLOC 0
#define FREE 1

spinlock_t biglock;
static size_t __spaces[MAX_FREELISTS];
int counts[MAX_FREELISTS];

static size_t length_all() {
  size_t all = 0;
  for (int i = 0; i < CPU_COUNT + 1; i++) {
    all += flength(&seglist[i]);
  }
  return all;
}

static size_t space_all() {
  size_t all = 0;
  for (int i = 0; i < CPU_COUNT + 1; i++) {
    all += fspace(&seglist[i]);
  }
  return all;
}

static void coarse_all() {
  for (int i = 0; i < CPU_COUNT + 1; i++) {
    coarse(&seglist[i]);
  }
}

static void assert_sorted(freelist_t *f) {
  for (freeh_t *p = head(f); (p != suffix(f)) && (p->next != suffix(f));
       p = p->next) {
    if (p > p->next) {
      perror("assert_sorted fail");
      exit(1);
    }
  }
}

static void begin_assert_coarsed() {
  for (int i = 0; i < CPU_COUNT + 1; i++) {
    __spaces[i] = fspace(&seglist[i]);
  }
}

static void end_assert_coarsed() {
  for (int i = 0; i < CPU_COUNT + 1; i++) {
    assert(flength(&seglist[i]) == 1);
    assert(__spaces[i] == fspace(&seglist[i]));
  }
}

void debug(const char *file, const int line, const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  printf("%s:%d ", file, line);
  vprintf(fmt, ap);
  va_end(ap);
}

static void alloc_free(int tid) {
  int N = 10000;
  for (int i = 0; i < N; i++) {
    int coin = rand() % 2;
    switch (coin) {
    case ALLOC: { // allocation
      int v = rand() % 128;
      alloch_t *ptr = (alloch_t *)(pmm->alloc(v));
      if (ptr == NULL) {
      } else {
        assert(inheap(ptr));
        assert((ptr - 1)->magic == MAGIC);
        assert((ptr - 1)->size == MAX(v, __LOW));
        set_insert(ptr, tid);
      }
      break;
    }
    case FREE: { // free
      void *ptr = set_pop(tid);
      if (ptr) {
        assert(inheap(ptr));
        pmm->free(ptr);
      }
      break;
    }
    }
    /*
     *if ((i + 1) % 1000 == 0) {
     *  DEBUG("finish [%d, %d)\n", i - 999, i + 1);
     *}
     */
  }
  // free the remaining
  while (!set_empty(tid)) {
    pmm->free(set_pop(tid));
  }
}

static void stress_alloc(int tid) {
  assert(tid < N_SET);
  int N = 10000, fail = 0;
  while (true) {
    counts[tid]++;
    int v = rand() % 4096;
    alloch_t *ptr = (alloch_t *)(pmm->alloc(v));
    if (ptr == NULL) {
      if (++fail == 10) {
        return;
      }
    } else {
      assert(inheap(ptr));
      assert((ptr - 1)->magic == MAGIC);
      assert((ptr - 1)->size == MAX(v, __LOW));
      set_insert(ptr, tid);
    }
  }
}

static void stress_alloc_free(int tid) {
  assert(tid < N_SET);
  int N = 10000, fail = 0;
  while (true) {
    int coin = rand() % 4; // alloc:free = 3:1
    if (coin > 0) {
      int v = rand() % 4096;
      alloch_t *ptr = (alloch_t *)(pmm->alloc(v));
      if (ptr == NULL) {
        if (++fail == 30) { // magic number :)
          return;
        }
      } else {
        counts[tid]++;
        assert(inheap(ptr));
        assert((ptr - 1)->magic == MAGIC);
        assert((ptr - 1)->size == MAX(v, __LOW));
        set_insert(ptr, tid);
      }
    } else {
      if (!set_empty(tid)) {
        pmm->free(set_pop(tid));
      }
    }
  }
}

static void test_seg(int tid) {
  begin_assert_coarsed();
  alloc_free(tid);
  coarse_all();
  end_assert_coarsed();
  DEBUG("------------------test_seg passed------------------\n\n");
}

static void test_thread(int T) {
  // the shared memory should NOT be included
  assert(T < N_SET);
  begin_assert_coarsed();
  for (int i = 0; i < T; i++) {
    create(alloc_free);
  }
  join();

  for (int i = 0; i < CPU_COUNT + 1; i++) {
    printf("----%d----\n", i);
    finfo(&seglist[i]);
  }
  coarse_all();
  end_assert_coarsed();
  DEBUG("------------------test_thread %d passed------------------\n\n", T);
}

static void test_stress_alloc(int T) {
  // the shared memory should NOT be included
  assert(T < N_SET);
  begin_assert_coarsed();
  for (int i = 0; i < T; i++) {
    create(stress_alloc);
  }
  join();

  // free all memory
  for (int id = 0; id < N_SET; id++) {
    while (!set_empty(id)) {
      pmm->free(set_pop(id));
    }
  }

  coarse_all();
  end_assert_coarsed();

  for (int i = 0; i < N_SET; i++) {
    printf("%d ", counts[i]);
  }

  /*
   *for (int i = 0; i < CPU_COUNT + 1; i++) {
   *  printf("----%d----\n", i);
   *  finfo(&seglist[i]);
   *}
   */

  // the allocated memory is freed by OS, bad practice :)
  DEBUG("------------------test_stress_alloc %d passed------------------\n\n",
        T);
}

static void test_stress_alloc_free(int T) {
  // the shared memory should NOT be included
  assert(T < N_SET);
  begin_assert_coarsed();
  for (int i = 0; i < T; i++) {
    create(stress_alloc_free);
  }
  join();

  // free all memory
  for (int id = 0; id < N_SET; id++) {
    while (!set_empty(id)) {
      pmm->free(set_pop(id));
    }
  }

  coarse_all();
  end_assert_coarsed();

  for (int i = 0; i < N_SET; i++) {
    printf("%d ", counts[i]);
  }

  // the allocated memory is freed by OS, bad practice :)
  DEBUG("------------------test_stress_alloc_free %d passed------------------\n\n",
        T);
}

int main(int argc, char *argv[]) {
  os->init();
  assert(argc == 2);
  const char *s = argv[1];
  if (strcmp(s, "seg") == 0) {
    test_seg(0);
  } else if (strcmp(s, "thread") == 0) {
    test_thread(4);
    test_thread(8);
  } else if (strcmp(s, "stress-alloc") == 0) {
    test_stress_alloc(4);
    // test_stress_alloc(8);
  } else if (strcmp(s, "stress-alloc-free") == 0) {
    test_stress_alloc_free(4);
  } else {
    printf("unknown test setting\n");
  }
}
