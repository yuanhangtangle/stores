#ifndef COMMON_H
#define COMMON_H

#include "lock.h"
#include <assert.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef TEST
#define CPU_COUNT 4
#else
#define CPU_COUNT cpu_count()
#endif

#define ENABLE_COARSING
#define COARSING 5
// constants
#define N_ITEMS 100000
#define MAX_CPU_COUNT 8 
#define MAX_FREELISTS MAX_CPU_COUNT + 1 // +1 for shared memory
#define N_SET MAX_CPU_COUNT + 1 // tid starts from 1, thus +1
#define FREEH_SIZE sizeof(freeh_t)
#define ALLOCH_SIZE sizeof(alloch_t)
#define HEAP_SIZE (8 * 1024 * 1024)
#define __HIGH (16 * 1024 * 1024)
#define __LOW FREEH_SIZE - ALLOCH_SIZE
#define MAGIC 0x1234567

// freelist operation
#define prefix(f) (&((f)->__prefix))
#define suffix(f) (&((f)->__suffix))
#define head(f) (prefix(f)->next)
#define start(f) ((f)->__start)
#define end(f) ((f)->__end)
#define dist(from, to) ((uintptr_t)(to) - (uintptr_t)(from))
#define forward(p, offset) ((freeh_t *)((uintptr_t)(p) + (uintptr_t)(offset)))
#define PRINT_FREEH(p)                                                         \
  { printf("%zu (%zu)\n", dist(heap.start, p), (p)->size); }

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) > (b) ? (b) : (a))

#define MODULE(mod)                                                            \
  typedef struct mod_##mod##_t mod_##mod##_t;                                  \
  extern mod_##mod##_t *mod;                                                   \
  struct mod_##mod##_t

#define MODULE_DEF(mod)                                                        \
  extern mod_##mod##_t __##mod##_obj;                                          \
  mod_##mod##_t *mod = &__##mod##_obj;                                         \
  mod_##mod##_t __##mod##_obj

MODULE(os) {
  void (*init)();
  void (*run)();
};

MODULE(pmm) {
  void (*init)();
  void *(*alloc)(size_t size);
  void (*free)(void *ptr);
};

// big lock for testing
extern spinlock_t biglock;
// Memory area for [@start, @end)
typedef struct {
  void *start, *end;
} Area;
extern Area heap;

// free list header
struct __free_header_t {
  size_t size;
  struct __free_header_t *next;
  struct __free_header_t *pre;
};
typedef struct __free_header_t freeh_t;

// free list
struct __freelist_t {
  freeh_t __prefix, __suffix;
  freeh_t *__start, *__end;
	int nfail;
  spinlock_t lk;
};
typedef struct __freelist_t freelist_t;
extern freelist_t seglist[MAX_FREELISTS];
extern freelist_t *f;

// alloc header
struct __alloc_header_t {
  size_t size, magic;
};
typedef struct __alloc_header_t alloch_t;

// allocation list
/* TODO:  <30-07-23, Not Implementation> */
struct __node {
  struct __node *next;
};
typedef struct __node *node;
extern node *prefix_node, *suffix_node;

// debugging
void debug(const char *file, const int line, const char *fmt, ...);
bool inrange(void *p, void *start, void *end);
bool inheap(void *p);
bool inflist(void *p, freelist_t *f);
void finfo(freelist_t *f);
void fprin(freelist_t *f);

// freeh_t operation
void insert(freeh_t *pre, freeh_t *fsp, size_t size);
void replace(freeh_t *oldp, freeh_t *newp);
freeh_t *probe(freelist_t *f, size_t size);
void delete(freeh_t *p);

// freelist_h operation
void freelist_init(freelist_t *f, freeh_t *start, size_t size);
size_t fspace(freelist_t *f);
size_t flength(freelist_t *f);
int findex(void *p);
void sort(freelist_t *f);
void coarse(freelist_t *f);
void print_list(freelist_t *f);

// set operation
void set_insert(void *ele, int id);
void *set_pop(int id);
bool set_empty(int id);

#endif
