#include "common.h"
static void os_init() {
  pmm->init();
}

// cpu_current is in am.h
// it returns an int
#ifndef TEST
static void os_run() {
  for (const char *s = "Hello World from CPU #*\n"; *s; s++) {
    putch(*s == '*' ? '0' + cpu_current() : *s);
  }
  while (1) ;
}
#else
static void os_run() {
	printf("%s:%d TEST defined\n", __FILE__, __LINE__);
}
#endif

MODULE_DEF(os) = {
  .init = os_init,
  .run  = os_run,
};
