#include "common.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#define move_forward(fp, offset)                                               \
  {                                                                            \
    freeh_t *__newFp = forward(fp, offset);                                    \
    replace(fp, __newFp);                                                      \
    /* the 2 headers may overlap in memory, thus `replace` should happen       \
     * before assigning the size */                                            \
    __newFp->size = fp->size - offset;                                         \
  }
#define DEBUG(...)                                                             \
  { debug(__FILE__, __LINE__, __VA_ARGS__); }


/* NOTE: use __LOW to avoid allocating small pieces */
static void *kalloc(size_t size) {
  if (size > __HIGH)
    return NULL;
  freeh_t *p;
  freelist_t *f;
  void *rc;
  size = MAX(size, __LOW);
  int n = rand() % CPU_COUNT;
  for (int __i = 0; __i < CPU_COUNT; __i++) { // iterate over all possible lists
    n = (n + 1) % CPU_COUNT;
    f = &seglist[n];
    spin_lock(&f->lk);
    p = probe(f, size);
    if (p == NULL) {
      spin_unlock(&f->lk); // unlock if fails
    } else {
      break;
    }
  }
  // fail in local memory, try the shared memory
  if (p == NULL) {
    f = &seglist[CPU_COUNT]; // probe the shared memory
    spin_lock(&f->lk);
    p = probe(f, size);
    if (p == NULL) {
      spin_unlock(&f->lk); // fail; lock released
    }
  }
  // fail in both local and shared memory
  if (p == NULL) {
    rc = NULL;
  } else { // succeeds, lock is not released
    uintptr_t offset = ALLOCH_SIZE + size;
    move_forward(p, offset);
    // NOTE: lock released
    spin_unlock(&f->lk);
    // since the memory is already allocated, lock is not needed
    alloch_t *ap = (alloch_t *)p;
    ap->size = size;
    ap->magic = MAGIC;
    rc = (void *)(ap + 1);
  }
  return rc;
}

/* NOTE: Use __LOW to avoid allocating small pieces */
static void kfree(void *ptr) {
  assert(ptr != NULL);
  /* NOTE: `findex` is NOT protected by lock*/
  int idx = findex(ptr);
  if (idx == -1) {
    perror("pointer address NOT found in the segregate lists");
    exit(1);
  }
  alloch_t *h = (alloch_t *)ptr - 1;
  assert(h->magic == MAGIC);
  // memory pieces < FREEH_SIZE can NOT accommodate freeh_t
  if (h->size + ALLOCH_SIZE >= FREEH_SIZE) {
    freelist_t *f = &seglist[idx];
    size_t size = h->size + ALLOCH_SIZE - FREEH_SIZE;
    freeh_t *fh = (freeh_t *)h;
    spin_lock(&f->lk);
    insert(prefix(f), fh, size);
    spin_unlock(&f->lk);
  }
}

#ifdef TEST
Area heap;
#endif

#ifdef TEST
static void pmm_init() {
  heap.start = malloc(HEAP_SIZE);
  heap.end = (void *)forward(heap.start, HEAP_SIZE);
  size_t seg_size = HEAP_SIZE / (CPU_COUNT + 1), size;
  freeh_t *start;
  for (int i = 0; i < (CPU_COUNT + 1); i++) {
    start = forward(heap.start, seg_size * i);
    size = (i == CPU_COUNT ? dist(start, heap.end) : seg_size);
    freelist_init(&seglist[i], start, size);
  }
  /* TODO:  <28-07-23, %zu is not implemented in klib/stdio.h> */
  DEBUG("allocated space: %zu\n", HEAP_SIZE);
	/*
   *for (int i = 0; i < (CPU_COUNT + 1); i++) {
   *  fprin(&seglist[i]);
   *}
	 */
  /*DEBUG("Got %d * %zu KiB = %zu free space\n", CPU_COUNT + 1,*/
  /*head(&seglist[0])->size, (CPU_COUNT + 1) * head(&seglist[0])->size);*/
}
#else
static void pmm_init() {
  uintptr_t pmsize = ((uintptr_t)heap.end - (uintptr_t)heap.start);
  printf("Got %d MiB heap: [%p, %p)\n", pmsize >> 20, heap.start, heap.end);
}
#endif

MODULE_DEF(pmm) = {
    .init = pmm_init,
    .alloc = kalloc,
    .free = kfree,
};
