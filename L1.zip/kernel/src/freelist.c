#include "common.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>

freelist_t seglist[MAX_FREELISTS];
freelist_t *f = &seglist[CPU_COUNT];

bool inflist(void *p, freelist_t *f) {
  return inrange(p, (void *)start(f), (void *)end(f));
}
/*check whether p is in heap*/
bool inheap(void *p) { return inrange(p, heap.start, heap.end); }

/*check whether pointer `p` is in [start, end)*/
bool inrange(void *p, void *start, void *end) {
  return (start <= p) && (p < end);
}

// freeh_t operation
void insert(freeh_t *pre, freeh_t *newp, size_t size) {
  /* size: size of the free space*/
  freeh_t *next = pre->next;
  newp->size = size;
  newp->next = next;
  newp->pre = pre;
  pre->next = newp;
  next->pre = newp;
}

void replace(freeh_t *oldp, freeh_t *newp) {
  freeh_t *pre = oldp->pre, *next = oldp->next;
  newp->next = next;
  newp->pre = pre;
  pre->next = newp;
  next->pre = newp;
}

void delete(freeh_t *p) {
  p->pre->next = p->next;
  p->next->pre = p->pre;
}

void freelist_init(freelist_t *f, freeh_t *start, size_t size) {
  start->pre = prefix(f);
  start->next = suffix(f);
  start->size = size - FREEH_SIZE;
  start(f) = start;
  end(f) = forward(start, size);
  prefix(f)->pre = NULL;
  prefix(f)->next = start; // head
  suffix(f)->pre = start;
  suffix(f)->next = NULL;
	f->nfail = 0;
}

/* TODO:
 *  1. boundary NOT considered;
 *  2. shared memory NOT considered;
 */
freeh_t *probe(freelist_t *f, size_t size) {
  size_t total = size + ALLOCH_SIZE;
  for (freeh_t *p = head(f); p != suffix(f); p = p->next) {
    if (p->size >= total) {
			return p;
    }
  }
#ifdef ENABLE_COARSING
	if(++(f->nfail) == COARSING){
		coarse(f);
		f->nfail = 0;
	}
#endif
  return NULL;
}

size_t fspace(freelist_t *f) {
  size_t total = 0;
  for (freeh_t *p = head(f); p != suffix(f); p = p->next) {
    total += p->size;
  }
  return total;
}

/*returns the length of the freelist, prefix and suffix excluded*/
size_t flength(freelist_t *f) {
  size_t n = 0;
  for (freeh_t *p = head(f); p != suffix(f); p = p->next)
    n++;
  return n;
}

int findex(void *p) {
  for (int i = 0; i < CPU_COUNT + 1; ++i) {
    if (inflist(p, &seglist[i])) {
      return i;
    }
  }
  return -1;
}

// sort by insertion
void sort(freelist_t *f) {
  freeh_t *p;
  for (freeh_t *a = prefix(f);
       (a->next != suffix(f)) && (a->next->next != suffix(f)); a = a->next) {
    p = a->next;
    for (freeh_t *b = p->next; b != suffix(f); b = b->next) {
      if (b < p)
        p = b;
    }
    if (p == a->next)
      continue;
    else {
      delete (p);
      insert(a, p, p->size);
    }
  }
}

void coarse(freelist_t *f) {
  sort(f);
  freeh_t *p = head(f);
  while (p && (p != suffix(f)) && (p->next != suffix(f))) {
    if ((uintptr_t)p + FREEH_SIZE + p->size == (uintptr_t)(p->next)) {
      size_t s = p->next->size + FREEH_SIZE;
      delete (p->next);
      p->size += s;
    } else {
      p = p->next;
    }
  }
}

/* NOTE: lock protection */
void fprin(freelist_t *f) {
  printf("range: [%lu, %lu)\n", dist(heap.start, start(f)),
         dist(heap.start, end(f)));
  printf("remaining free space: %zu\n", fspace(f));
  for (freeh_t *p = head(f); p != suffix(f); p = p->next) {
    PRINT_FREEH(p);
  }
  printf("\n");
}

void finfo(freelist_t *f) {
  printf("range: [%zu, %zu)\n", dist(heap.start, start(f)),
         dist(heap.start, end(f)));
  printf("length: %zu\n", flength(f));
  printf("free space: %zu\n", fspace(f));
}
