#include "common.h"
#include <assert.h>

// MAX_CPU_COUNT + 1 because tid in `thread.h` start from 1
int count[N_SET], total[N_SET];
void *items[N_SET][N_ITEMS];

/*each thread has its own set, thus lock protection is NOT required*/
void set_insert(void *ele, int id) {
  assert(id < N_SET);
  items[id][total[id]] = ele;
  count[id]++, total[id]++;
}

void *set_pop(int id) {
  assert(id < N_SET);
  void *p;
  if (count[id] == 0) {
    p = NULL;
  } else {
    int n = rand() % total[id];
    while (items[id][n] == NULL) {
      n = (n + 1) % total[id];
    }
    p = items[id][n];
    count[id]--;
    items[id][n] = NULL;
  }
  return p;
}

bool set_empty(int id) {
  assert(id <= N_SET);
  return count[id] == 0;
}
